package com.assignment.Assignment;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.assignment.dto.TransferRequest;
import com.assignment.exception.AccountNotFoundException;
import com.assignment.exception.InsufficientBalanceException;
import com.assignment.exception.InvalidRequestException;
import com.assignment.model.Account;
import com.assignment.repository.AccountRepository;
import com.assignment.service.AccountService;
import com.assignment.service.AccountServiceImpl;

@SpringBootTest
class AssignmentApplicationTests {

	@Autowired
	private AccountServiceImpl accountServiceImpl;
	@Autowired
	private AccountService accountService;
	@MockBean
	private AccountRepository accountRepository;

	@Test
	public void fetchAccountDetails_Valid_Account_Test() {
		String accountNumber = "10";
		Account account = new Account();
		account.setAccountNumber("10");
		account.setBalance((double) 100);
		when(accountRepository.findByAccountNumber(accountNumber)).thenReturn(account);
		assertEquals(account, accountServiceImpl.fetchAccountDetails(accountNumber));
	}

	@Test
	public void fetchAccountDetails_Invalid_Account_Test() {
		String accountNumber = "10";
		Account account = null;
		when(accountRepository.findByAccountNumber(accountNumber)).thenReturn(account);
		assertThrows(AccountNotFoundException.class, () -> {
			accountServiceImpl.fetchAccountDetails(accountNumber);
		});
	}

	
	@Test
	public void updateBalance_Passed_Transanction_Test() throws AccountNotFoundException, InsufficientBalanceException, InvalidRequestException {
		TransferRequest transferRequest = new TransferRequest();
		
		String senderAccountNumber = "10";
		String beneficiaryAccountNumber = "11";
		Double transferAmount = (double) 1000;
		
		Account senderAccount = new Account();
		Account updatedSenderAccount = new Account();
		Account beneficiaryAccount = new Account();
		Account updatedBeneficiaryAccount = new Account();
		
		senderAccount.setAccountNumber(senderAccountNumber);
		senderAccount.setBalance((double) 10000);
		
		updatedSenderAccount.setAccountNumber(senderAccountNumber);
		updatedSenderAccount.setBalance((double) 9000);
		
		beneficiaryAccount.setAccountNumber(beneficiaryAccountNumber);
		beneficiaryAccount.setBalance((double) 20000);
		
		updatedBeneficiaryAccount.setAccountNumber(beneficiaryAccountNumber);
		updatedBeneficiaryAccount.setBalance((double) 21000);
		
		transferRequest.setSenderAccountNumber(senderAccountNumber);
		transferRequest.setBeneficiaryAccountNumber(beneficiaryAccountNumber);
		transferRequest.setTransferAmount(transferAmount);
		
		when(accountRepository.findByAccountNumber(senderAccountNumber)).thenReturn(senderAccount);
		when(accountRepository.findByAccountNumber(beneficiaryAccountNumber)).thenReturn(beneficiaryAccount);
		when(accountRepository.save(updatedSenderAccount)).thenReturn(updatedSenderAccount);
		when(accountRepository.save(updatedBeneficiaryAccount)).thenReturn(updatedBeneficiaryAccount);
		List<Account> updatedAccounts = accountService.updateBalance(transferRequest);
		Account sender = updatedAccounts.get(0);
		Account beneficiary = updatedAccounts.get(1);
		assertEquals(senderAccountNumber, sender.getAccountNumber());
		assertEquals(9000, sender.getBalance());
		assertEquals(beneficiaryAccountNumber, beneficiary.getAccountNumber());
		assertEquals(21000, beneficiary.getBalance());
	}
	
	@Test
	public void updateBalance_Failed_Transanction_Duplicate_Account_Test() throws AccountNotFoundException, InsufficientBalanceException, InvalidRequestException {
		TransferRequest transferRequest = new TransferRequest();
		
		String senderAccountNumber = "10";
		String beneficiaryAccountNumber = "10";
		Double transferAmount = (double) 1000;
		
		Account senderAccount = new Account();
		Account beneficiaryAccount = new Account();
		
		senderAccount.setAccountNumber(senderAccountNumber);
		senderAccount.setBalance((double) 10000);
		
		beneficiaryAccount.setAccountNumber(beneficiaryAccountNumber);
		beneficiaryAccount.setBalance((double) 20000);
		
		transferRequest.setSenderAccountNumber(senderAccountNumber);
		transferRequest.setBeneficiaryAccountNumber(beneficiaryAccountNumber);
		transferRequest.setTransferAmount(transferAmount);
		
		assertThrows(InvalidRequestException.class, () -> {
			accountService.updateBalance(transferRequest); });
	}
	
	@Test
	public void updateBalance_Failed_Transanction_Insufficient_Balance_Test() throws AccountNotFoundException, InsufficientBalanceException, InvalidRequestException {
		TransferRequest transferRequest = new TransferRequest();
		
		String senderAccountNumber = "10";
		String beneficiaryAccountNumber = "11";
		Double transferAmount = (double) 10000;
		
		Account senderAccount = new Account();
		Account beneficiaryAccount = new Account();
		
		senderAccount.setAccountNumber(senderAccountNumber);
		senderAccount.setBalance((double) 1000);
		
		beneficiaryAccount.setAccountNumber(beneficiaryAccountNumber);
		beneficiaryAccount.setBalance((double) 20000);
		
		transferRequest.setSenderAccountNumber(senderAccountNumber);
		transferRequest.setBeneficiaryAccountNumber(beneficiaryAccountNumber);
		transferRequest.setTransferAmount(transferAmount);
		when(accountRepository.findByAccountNumber(senderAccountNumber)).thenReturn(senderAccount);
		assertThrows(InsufficientBalanceException.class, () -> {
			accountService.updateBalance(transferRequest); });
	}
	
	@Test
	public void updateBalance_Failed_Transanction_Invalid_Sender_Account_Test() throws AccountNotFoundException, InsufficientBalanceException, InvalidRequestException {
		TransferRequest transferRequest = new TransferRequest();
		
		String senderAccountNumber = "10";
		String beneficiaryAccountNumber = "13";
		Double transferAmount = (double) 1000;
		
		Account senderAccount = null;
		Account beneficiaryAccount = new Account();
		
		beneficiaryAccount.setAccountNumber(beneficiaryAccountNumber);
		beneficiaryAccount.setBalance((double) 20000);
		
		transferRequest.setSenderAccountNumber(senderAccountNumber);
		transferRequest.setBeneficiaryAccountNumber(beneficiaryAccountNumber);
		transferRequest.setTransferAmount(transferAmount);
		
		when(accountRepository.findByAccountNumber(senderAccountNumber)).thenReturn(senderAccount);
		when(accountRepository.findByAccountNumber(beneficiaryAccountNumber)).thenReturn(beneficiaryAccount);
		when(accountRepository.save(senderAccount)).thenReturn(senderAccount);
		assertThrows(AccountNotFoundException.class, () -> {
			accountService.updateBalance(transferRequest); });
	}
	
	@Test
	public void updateBalance_Failed_Transanction_Invalid_Beneficiary_Account_Test() throws AccountNotFoundException, InsufficientBalanceException, InvalidRequestException {
		TransferRequest transferRequest = new TransferRequest();
		
		String senderAccountNumber = "10";
		String beneficiaryAccountNumber = "13";
		Double transferAmount = (double) 1000;
		
		Account senderAccount = new Account();
		Account beneficiaryAccount = null;
		
		senderAccount.setAccountNumber(senderAccountNumber);
		senderAccount.setBalance((double) 10000);
		
		transferRequest.setSenderAccountNumber(senderAccountNumber);
		transferRequest.setBeneficiaryAccountNumber(beneficiaryAccountNumber);
		transferRequest.setTransferAmount(transferAmount);
		
		when(accountRepository.findByAccountNumber(senderAccountNumber)).thenReturn(senderAccount);
		when(accountRepository.findByAccountNumber(beneficiaryAccountNumber)).thenReturn(beneficiaryAccount);
		when(accountRepository.save(senderAccount)).thenReturn(senderAccount);
		assertThrows(AccountNotFoundException.class, () -> {
			accountService.updateBalance(transferRequest); });
	}

}
