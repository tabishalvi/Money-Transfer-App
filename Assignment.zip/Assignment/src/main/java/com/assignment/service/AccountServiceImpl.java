package com.assignment.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.assignment.dto.TransferRequest;
import com.assignment.exception.AccountNotFoundException;
import com.assignment.exception.InsufficientBalanceException;
import com.assignment.exception.InvalidRequestException;
import com.assignment.model.Account;
import com.assignment.repository.AccountRepository;

@org.springframework.stereotype.Service
public class AccountServiceImpl implements AccountService{

	@Autowired
	private AccountRepository repo;

	public List<Account> processTransferRequest(TransferRequest tr) throws InsufficientBalanceException, AccountNotFoundException{
			 List<Account> updatedAccounts = new ArrayList<>();
			 Account senderUpdatedAccount = withdrawAmount(tr.getSenderAccountNumber(), tr.getTransferAmount());
			 Account beneficiaryUpdatedAccount = depositAmount(tr.getBeneficiaryAccountNumber(), tr.getTransferAmount());
			 updatedAccounts.add(senderUpdatedAccount);
			 updatedAccounts.add(beneficiaryUpdatedAccount);
			 return updatedAccounts;
		 }
	
	public Account withdrawAmount(String accountNumber, Double withdrawAmount) throws InsufficientBalanceException, AccountNotFoundException {
		    //Before withdrawing money we can check for valid beneficiary account as well but in this implementation I am checking it after withdrawing to show transaction roll back feature in case of failure
			Account senderAccountDetails = fetchAccountDetails(accountNumber);
			if (senderAccountDetails.getBalance() < withdrawAmount)
				throw new InsufficientBalanceException(
						"Inssufficient balance in account with account number:" + accountNumber);
			else {
				Double balance = senderAccountDetails.getBalance() - withdrawAmount;
				senderAccountDetails.setAccountNumber(accountNumber);
				senderAccountDetails.setBalance(balance);
				senderAccountDetails = repo.save(senderAccountDetails);
			}
			return senderAccountDetails;
		}
	
	public Account depositAmount(String accountNumber, Double depositAmount) throws InsufficientBalanceException, AccountNotFoundException{
		    Account beneficiaryAccountDetails = fetchAccountDetails(accountNumber);
			Double balance = beneficiaryAccountDetails.getBalance() + depositAmount;
			beneficiaryAccountDetails.setAccountNumber(accountNumber);
			beneficiaryAccountDetails.setBalance(balance);
			beneficiaryAccountDetails = repo.save(beneficiaryAccountDetails);
			return beneficiaryAccountDetails;
		}

	@Override
	public List<Account> updateBalance(TransferRequest tr) throws AccountNotFoundException, InsufficientBalanceException, InvalidRequestException {
		List<Account> updatedAccounts = new ArrayList<>();
		if(tr.getSenderAccountNumber().equalsIgnoreCase(tr.getBeneficiaryAccountNumber())) {
			throw new InvalidRequestException("Sender and Beneficiary account number should be different");
		}else {
			updatedAccounts = processTransferRequest(tr);
		}
		return updatedAccounts;
	}

	@Override
	public Account fetchAccountDetails(String accountNumber) throws AccountNotFoundException {
		Account account = repo.findByAccountNumber(accountNumber);
		if(account!=null) return account;
		else throw new AccountNotFoundException("No records found for Account Number: "+ accountNumber);
	
		
	}
}
