package com.assignment.service;

import java.util.List;

import org.hibernate.exception.LockAcquisitionException;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.assignment.dto.TransferRequest;
import com.assignment.exception.AccountNotFoundException;
import com.assignment.exception.InsufficientBalanceException;
import com.assignment.exception.InvalidRequestException;
import com.assignment.model.Account;

public interface AccountService {

	@Transactional(isolation=Isolation.REPEATABLE_READ,propagation=Propagation.REQUIRED,rollbackFor= {AccountNotFoundException.class,LockAcquisitionException.class})
	public List<Account> updateBalance(TransferRequest tr) throws AccountNotFoundException, InsufficientBalanceException,InvalidRequestException;
	
	public Account fetchAccountDetails(String accountNumber) throws AccountNotFoundException;
}
