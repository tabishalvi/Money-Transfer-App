package com.assignment.exception.handler;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.assignment.exception.AccountNotFoundException;
import com.assignment.exception.InsufficientBalanceException;
import com.assignment.exception.InvalidRequestException;

@RestControllerAdvice
public class ApplicationexceptionHandler {
	
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleInvalidArgument(MethodArgumentNotValidException ex){
		Map<String, String> errMap = new HashMap<>();
		ex.getBindingResult().getFieldErrors().forEach(error ->{
			errMap.put(error.getField(), error.getDefaultMessage());
		});
		return errMap;
	}
	
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(AccountNotFoundException.class)
	public Map<String, String> handleInvalidAccount(AccountNotFoundException ex){
		Map<String, String> errMap = new HashMap<>();
		errMap.put("erroeMessage", ex.getMessage());
		return errMap;
	}
	
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(InvalidRequestException.class)
	public Map<String, String> handleInvalidRequest(InvalidRequestException ex){
		Map<String, String> errMap = new HashMap<>();
		errMap.put("erroeMessage", ex.getMessage());
		return errMap;
	}
	
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(InsufficientBalanceException.class)
	public Map<String, String> handleInvalidRequest(InsufficientBalanceException ex){
		Map<String, String> errMap = new HashMap<>();
		errMap.put("erroeMessage", ex.getMessage());
		return errMap;
	}
}
