package com.assignment.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransferRequest {

	@NotNull(message = "senderAccountNumber should not be null")
	@NotBlank(message = "senderAccountNumber should not be blank")
	private String senderAccountNumber;
	
	@NotNull(message = "beneficiaryAccountNumber should not be null")
	@NotBlank(message = "beneficiaryAccountNumber should not be blank")
	private String beneficiaryAccountNumber;
	
	@NotNull(message = "transferAmount should not be null")
	@Positive(message = "transferAmount should be greater than zero")
	private Double transferAmount;
}
