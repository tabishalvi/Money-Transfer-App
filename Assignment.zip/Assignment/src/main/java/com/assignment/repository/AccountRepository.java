package com.assignment.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.assignment.model.Account;

@org.springframework.stereotype.Repository
public interface AccountRepository extends JpaRepository<Account, String>{

	public Account findByAccountNumber(String accountNumber);
	
	/*
	 * @SuppressWarnings("unchecked") public Account save(Account account);
	 */

}
