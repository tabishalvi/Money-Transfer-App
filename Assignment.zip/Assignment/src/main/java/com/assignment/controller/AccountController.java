package com.assignment.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.CannotAcquireLockException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.dto.TransferRequest;
import com.assignment.exception.AccountNotFoundException;
import com.assignment.exception.InsufficientBalanceException;
import com.assignment.exception.InvalidRequestException;
import com.assignment.model.Account;
import com.assignment.service.AccountService;

@RestController
@RequestMapping("/account")
public class AccountController {

	@Autowired
	private AccountService service;
	 

	@GetMapping("/get/{id}")
	public ResponseEntity<Account> getAccountDetails(@PathVariable String id) throws AccountNotFoundException{
		return new ResponseEntity<>(service.fetchAccountDetails(id), HttpStatus.OK);
	}
	
	@PostMapping("/transfer")
	public ResponseEntity<String> transferMoney(@RequestBody @Valid TransferRequest tr) throws InvalidRequestException, InsufficientBalanceException, AccountNotFoundException{
		try {
			service.updateBalance(tr);
		}catch(CannotAcquireLockException e) {
			//Alternatively we can also throw a runtime exception indicating user to try again after some time.
			service.updateBalance(tr);
		 } 
		 return new ResponseEntity<>("Money transfer successfull", HttpStatus.OK);
	}
}
